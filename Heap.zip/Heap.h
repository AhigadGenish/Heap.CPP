#include <iostream>
#pragma once
using namespace std;

class Heap
{
	int* _arr;
	int _size;
	int _maxSize;

public:
	int* getArr() const {
		return this->_arr;
	}
	int getIndexArr(int i) const {
		return this->_arr[i];
	}
	int getSize()const {
		return this->_size;
	}
	int getMaxSize()const {
		return this->_maxSize;
	}
	void heapify(Heap other, int i);
	void setSize(int size);
	void setIndex(int j , int value);
	void setMaxSize(int maxSize);
	void swapElements(int* a, int* b);
	void printHeap()const;
	void insert(int k);
	int findMin();
	int delMin();
	Heap& operator=(const Heap& other);
	Heap(const Heap& other);
	Heap(int maxSize);
	~Heap();

};

