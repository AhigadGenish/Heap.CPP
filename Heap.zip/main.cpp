#include "Heap.h"
void heapSort(int* arr,int n) {

	Heap heap(n);
	for (int i = 0;i < n;i++)
		heap.insert(arr[i]);
	for (int i = 0;i < n;i++)
		arr[i] = heap.delMin();

}
void printArr(int* arr,int n) {
	cout << "The array is: " << endl;
	for (int i = 0;i < n;i++)
		cout << arr[i] << endl;
}
int main() {

	Heap H(10);
	for (int i = 10;i > 1;i--)
		H.insert(i);
	H.printHeap();
	cout <<"The min in the heap: "<< H.findMin() << endl;
	H.insert(0);
	H.printHeap();
	
	int arr[10] = { 2,0,3,1,7,5,8,4,9,6 };
	heapSort(arr, 10);
	printArr(arr, 10);


	return 0;
}