#include "Heap.h"
void Heap :: swapElements(int* a, int* b)
{
	int temp = *a;
	*a = *b;
	*b = temp;
}

void Heap:: setSize(int size) {
	this->_size = size;
}
void Heap:: setIndex(int j, int value) {
	this->_arr[j] = value;
}
void Heap:: setMaxSize(int maxSize) {
	this->_maxSize = maxSize;
}
void Heap:: insert(int k) {

	if (this->getSize() == this->getMaxSize()) {
		cout << "the Heap is full" << endl;
		return;
	}
	else {
		this->setSize(this->getSize() + 1);
		this->setIndex(this->getSize(), k);
		int i = this->getSize();
		while (i > 1 && this->getIndexArr(i) < this->getIndexArr(floor((i / 2)))) {
			int j = floor(i / 2) ;
			swapElements(&this->_arr[i], &this->_arr[j]);
			i = j;

		}
	}
}
int Heap:: findMin() {
	if(this->getSize())
		return this->getIndexArr(1);
	else 
		cout << "Heap is empty" << endl;
	
}
int Heap:: delMin() {
	if (this->getSize() == 0) {
		cout << "Heap is empty" << endl;
		return -1;
	}
	int min = this->getIndexArr(1);
	this->setIndex(1, this->getIndexArr(this->getSize()));
	this->setSize(this->getSize() - 1);
	if (this->getSize() > 1)
		heapify(*this, 1);
	return min;
}
void Heap::heapify(Heap heap, int i) {

	if (2 * i > heap.getSize()) {
		*this = heap;
		return;
	}
	if (2 * i + 1 > heap.getSize()) {
		if (heap.getIndexArr(i) > heap.getIndexArr(2 * i))
			swapElements(&heap._arr[i], &heap._arr[2 * i]);
		*this = heap;
		return;
	}
	else {
		int j = 0;
		if (heap.getIndexArr(2 * i) < heap.getIndexArr(2 * i + 1))
			j = 2 * i;
		else
			j = 2 * i + 1;
		if (heap.getIndexArr(i) > heap.getIndexArr(j)) {
			swapElements(&heap._arr[i], &heap._arr[j]);
			heapify(heap, j);
		}
		else {
			*this = heap;
			return;
		}
	}
}
Heap& Heap:: operator=(const Heap& other) {

	this->setMaxSize(other.getMaxSize());
	this->setSize(other.getSize());
	this->_arr = new int[this->getMaxSize()];
	for (int i = 0; i < this->getSize()+1;i++) {
		this->setIndex(i, other.getIndexArr(i));
	}
	return *this;

}
void Heap:: printHeap() const {
	cout << "The Heap :" << endl;
	cout << "Size:" << this->getSize() << endl;
	for (int i = 1; i < this->getSize()+1;i++) {
		cout << this->getIndexArr(i)<<" ";
	}
	cout << endl;
}
Heap:: Heap(const Heap& other) {

	this->setMaxSize(other.getMaxSize());
	this->setSize(other.getSize());
	this->_arr = new int[this->getMaxSize()];
	for (int i = 0; i < this->getSize()+1;i++) {
		this->setIndex(i, other.getIndexArr(i));
	}
}
Heap::Heap(int maxSize) {
	if (maxSize) {
		this->_arr = new int[maxSize + 1];
		this->setIndex(0, -1);
	}
	else
		this->_arr = NULL;
	this->setMaxSize(maxSize);
	
}
Heap:: ~Heap() {
	if (this->_arr != NULL)
		delete this->_arr;
	
}